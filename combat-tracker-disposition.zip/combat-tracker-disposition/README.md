# Combat Tracker Disposition

This module highlights combatants in the combat tracker with their token's disposition. 

You can additionally configure your own colours.

![image](https://user-images.githubusercontent.com/77904738/170281565-bebe588d-4b47-48e7-b6cb-a51c965ea362.png)
